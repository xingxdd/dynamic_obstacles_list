#ifndef __TALKER_H__
#define __TALKER_H__
extern double all_x,all_y;
double all_x=1.9,all_y=0;
#endif